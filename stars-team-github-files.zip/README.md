# Lunar & Mars Field Atlas

Ay ve Mars için aday araştırma bölgelerini ve Dünya analog alanlarını karşılaştıran Türkçe/İngilizce interaktif web atlası.

## Çalıştırma

`index.html` dosyasını bir web tarayıcısında açın.

## GitHub Pages

Depoda **Settings → Pages** bölümüne gidin. **Deploy from a branch** seçeneğini, `main` dalını ve `/ (root)` klasörünü seçip kaydedin.
